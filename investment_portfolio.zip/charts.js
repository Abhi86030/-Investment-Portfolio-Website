
const ctx = document.getElementById('candlestickChart').getContext('2d');

const candlestickData = {
    labels: ['Day 1', 'Day 2', 'Day 3', 'Day 4', 'Day 5'],
    datasets: [{
        label: 'Stock Price',
        data: [
            { o: 100, h: 120, l: 90, c: 110 },
            { o: 110, h: 130, l: 100, c: 120 },
            { o: 120, h: 125, l: 115, c: 122 },
            { o: 122, h: 135, l: 120, c: 128 },
            { o: 128, h: 140, l: 125, c: 130 }
        ],
        type: 'candlestick'
    }]
};

const chart = new Chart(ctx, {
    type: 'candlestick',
    data: candlestickData,
    options: {
        scales: {
            x: {
                type: 'category',
                labels: candlestickData.labels
            },
            y: {
                beginAtZero: false,
                ticks: {
                    callback: (value) => '$' + value
                }
            }
        }
    }
});
