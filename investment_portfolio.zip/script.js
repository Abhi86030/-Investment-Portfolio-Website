
const buyBtn = document.getElementById('buyBtn');
const sellBtn = document.getElementById('sellBtn');
const result = document.getElementById('transactionResult');

buyBtn.addEventListener('click', () => {
    result.textContent = 'You have bought stock!';
    result.style.color = 'green';
});

sellBtn.addEventListener('click', () => {
    result.textContent = 'You have sold stock!';
    result.style.color = 'red';
});
